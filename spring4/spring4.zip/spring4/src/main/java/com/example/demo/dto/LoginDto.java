package com.example.demo.dto;

import lombok.*;

@Data
public class LoginDto {
	private String username;
	private String password;
}
