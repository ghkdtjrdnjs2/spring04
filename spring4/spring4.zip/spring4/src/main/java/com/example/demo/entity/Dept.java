package com.example.demo.entity;

import lombok.*;

@Data
@AllArgsConstructor
public class Dept {
	private Long deptno;
	private String dname;
	private String loc;
}
